---
name: Bug report
about: Report a bug
title: "[Bug] "
labels: bug
---

## What happened
## Expected behavior
## Steps to reproduce
## Logs / screenshots
## Environment
- OS:
- Python:
- Docker:
