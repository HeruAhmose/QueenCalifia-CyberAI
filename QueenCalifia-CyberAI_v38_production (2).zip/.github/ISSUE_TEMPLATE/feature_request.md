---
name: Feature request
about: Suggest an improvement
title: "[Feature] "
labels: enhancement
---

## Problem
## Proposed solution
## Alternatives
## Additional context
