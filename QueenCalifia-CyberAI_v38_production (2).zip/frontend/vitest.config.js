// Re-export from vite.config.js — vitest reads test config from there
export { default } from "./vite.config.js";
